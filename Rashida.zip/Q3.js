"use strict" // use strict treat all js code as newer version
a=20;
console.log(a);

// correct code is 
let a = 20;
console.log(a);