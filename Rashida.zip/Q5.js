let  num = "123";
num= true;
num=0;
num=null;
console.log(typeof (num));
let valueInNumber = Number(num);
console.log(valueInNumber);
//***************boolen*********************************** */
let  value = "123";
value= true;
value=0;
value=null;
console.log(typeof (value));
let valueInBoolen = Boolean(value);
console.log(valueInBoolen);
//**********************STRING******************************
let  score = "123"
score= true;
score=0;
score=null;
console.log(typeof (score));
let valueInString = String(score);
console.log(valueInString);
 8 changes: 8 additions & 0 deletions8  