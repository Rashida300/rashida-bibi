console.log("Hello,World!")
// this code show output on browser console.