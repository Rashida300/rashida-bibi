console.log("Rashida" > "Bibi")
