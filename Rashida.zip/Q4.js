let fullName= "Rashida Bibi";
let age=20;
var pass=true;
fullName= "Rashida"
age= 20;
pass=false;
console.log(fullName,age,pass);