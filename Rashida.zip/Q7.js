let a = 5;
let b=6;
let sum= a+b;
let subtract= a-b;
let multiply= a*b;
let divide= a/b;
console.log(sum,subtract,multiply,divide);